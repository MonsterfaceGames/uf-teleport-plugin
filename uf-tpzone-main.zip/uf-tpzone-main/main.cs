using System.Drawing;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Core.Attributes;
using CounterStrikeSharp.API.Core.Attributes.Registration;
using CounterStrikeSharp.API.Modules.Admin;
using CounterStrikeSharp.API.Modules.Commands;
using CounterStrikeSharp.API.Modules.Utils;
using CounterStrikeSharp.API.Modules.Memory;

namespace uf_tpzone;

[MinimumApiVersion(281)]
public class TpZonePlugin : BasePlugin
{
    public override string ModuleName => "UF-TPZone";
    public override string ModuleVersion => "2.0V";
    public override string ModuleAuthor => "monsterfacegames";
    public override string ModuleDescription => "Teleport zone plugin";

    private readonly Dictionary<int, PlayerZoneData> _players = new();
    private CBaseTrigger? _currentTrigger;
    private CBaseEntity? _currentDestination;
    private ZoneData? _currentZone;
    private int _spawnGen;
    private readonly Dictionary<int, float> _lastTeleportTime = new();

    private const string TriggerName = "tpzone_trigger";
    private const string DestName = "uf-tpzone";
    private string _configDir = "";
    private Database _db = null!;
    private readonly Dictionary<int, CBeam> _globalBeams = new();

    public override void Load(bool hotReload)
    {
        var gameDir = Server.GameDirectory;
        _configDir = Path.Join(gameDir, "csgo", "addons", "counterstrikesharp", "configs", "plugins", "uf-tpzone");

        if (!Directory.Exists(_configDir))
            Directory.CreateDirectory(_configDir);

        _db = new Database(_configDir);

        RegisterListener<Listeners.OnTick>(OnTick);
        RegisterListener<Listeners.OnMapStart>(OnMapStart);

        RegisterEventHandler<EventPlayerDisconnect>((@event, info) =>
        {
            if (@event.Userid is { IsValid: true })
                CleanupPlayer(@event.Userid.Slot);
            return HookResult.Continue;
        });

        RegisterEventHandler<EventRoundStart>((@event, info) =>
        {
            if (_currentZone != null)
            {
                _db.SaveZone(_currentZone);
                if (_currentTrigger == null || !_currentTrigger.IsValid || _currentDestination == null || !_currentDestination.IsValid)
                {
                    Server.NextFrame(() =>
                    {
                        if (_currentZone != null)
                        {
                            SpawnTrigger(_currentZone);
                            SpawnDest(_currentZone);
                        }
                    });
                }
            }
            return HookResult.Continue;
        });

        RegisterEventHandler<EventPlayerConnectFull>((@event, info) =>
        {
            if (_currentZone != null && @event.Userid is { IsValid: true })
            {
                var data = GetOrCreatePlayerData(@event.Userid.Slot);
                data.Corner1 = _currentZone.Corner1;
                data.Corner2 = _currentZone.Corner2;
                data.SpawnTarget = _currentZone.SpawnTarget;
                data.SpawnAngles = _currentZone.SpawnAngles;
            }
            return HookResult.Continue;
        });
    }

    private ZoneData? LoadZoneFromDb(string mapName)
    {
        try
        {
            return _db.LoadZone(mapName);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] LoadZoneFromDb error: {ex.Message}");
            return null;
        }
    }

    private void OnMapStart(string mapName)
    {
        RemoveCurrentEntities();
        foreach (var kvp in _players)
            CleanupPlayer(kvp.Key);
        _players.Clear();
        _lastTeleportTime.Clear();
        _currentZone = null;

        try
        {
            var zone = LoadZoneFromDb(mapName);
            if (zone != null)
            {
                _currentZone = zone;
                Server.NextFrame(() =>
                {
                    try
                    {
                        SpawnTrigger(zone);
                        SpawnDest(zone);

                        foreach (var player in Utilities.GetPlayers())
                        {
                            if (player == null || !player.IsValid || player.IsBot) continue;
                            var data = GetOrCreatePlayerData(player.Slot);
                            data.Corner1 = zone.Corner1;
                            data.Corner2 = zone.Corner2;
                            data.SpawnTarget = zone.SpawnTarget;
                            data.SpawnAngles = zone.SpawnAngles;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[TPZone] Auto-spawn error: {ex.Message}");
                    }
                });
                Console.WriteLine($"[TPZone] Loaded zone for {mapName} from database.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] OnMapStart error: {ex.Message}");
        }
    }

    private ZoneData BuildZoneFromPlayerData(PlayerZoneData data)
    {
        return new ZoneData
        {
            MapName = Server.MapName,
            Corner1 = data.Corner1 ?? "",
            Corner2 = data.Corner2 ?? "",
            SpawnTarget = data.SpawnTarget ?? "",
            SpawnAngles = data.SpawnAngles ?? "0 0 0"
        };
    }

    private void SpawnTrigger(ZoneData zone)
    {
        try
        {
            RemoveCurrentEntities();

            var c1 = ParseVector(zone.Corner1);
            var c2 = ParseVector(zone.Corner2);

            var minX = Math.Min(c1.X, c2.X);
            var maxX = Math.Max(c1.X, c2.X);
            var minY = Math.Min(c1.Y, c2.Y);
            var maxY = Math.Max(c1.Y, c2.Y);
            var minZ = Math.Min(c1.Z, c2.Z);
            var maxZ = Math.Max(c1.Z, c2.Z);

            var center = new Vector((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2);

            var trigger = Utilities.CreateEntityByName<CBaseTrigger>("trigger_teleport");
            if (trigger == null || !trigger.IsValid || trigger.Entity == null) return;
            trigger.Entity.Name = TriggerName;
            trigger.Target = DestName;
            trigger.Teleport(center, new QAngle(0, 0, 0), new Vector(0, 0, 0));
            if (trigger.Collision == null) return;
            trigger.Collision.Mins.X = minX - center.X;
            trigger.Collision.Mins.Y = minY - center.Y;
            trigger.Collision.Mins.Z = minZ - center.Z;
            trigger.Collision.Maxs.X = maxX - center.X;
            trigger.Collision.Maxs.Y = maxY - center.Y;
            trigger.Collision.Maxs.Z = maxZ - center.Z;
            trigger.DispatchSpawn();

            var capturedGen = ++_spawnGen;
            var capturedTrigger = trigger;
            Server.NextFrame(() =>
            {
                if (_spawnGen != capturedGen) return;
                try
                {
                    if (capturedTrigger.IsValid && capturedTrigger.Collision != null)
                        capturedTrigger.Collision.SolidType = (SolidType_t)2;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TPZone] Solid type error: {ex.Message}");
                }
            });

            _currentTrigger = trigger;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] SpawnTrigger error: {ex.Message}");
        }
    }

    private void SpawnDest(ZoneData zone)
    {
        if (_currentDestination != null && _currentDestination.IsValid)
            _currentDestination.Remove();

        try
        {
            var spawnPos = ParseVector(zone.SpawnTarget);
            var spawnAng = ParseVector(zone.SpawnAngles);

            var dest = Utilities.CreateEntityByName<CInfoTeleportDestination>("info_teleport_destination");
            if (dest == null || dest.Entity == null) return;
            dest.Entity.Name = DestName;
            dest.Teleport(spawnPos, new QAngle(spawnAng.X, spawnAng.Y, spawnAng.Z), new Vector(0, 0, 0));
            dest.DispatchSpawn();
            _currentDestination = dest;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] Failed to spawn destination: {ex.Message}");
        }
    }

    private void RemoveCurrentEntities()
    {
        if (_currentTrigger != null && _currentTrigger.IsValid)
            _currentTrigger.Remove();
        if (_currentDestination != null && _currentDestination.IsValid)
            _currentDestination.Remove();
        _currentTrigger = null;
        _currentDestination = null;
        RemoveGlobalBeams();
        _spawnGen++;
    }

    [ConsoleCommand("css_tpzone", "Open TPZone menu")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnTpZoneMenu(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;

        var data = GetOrCreatePlayerData(player.Slot);
        data.InMenu = true;
        PrintToMenu(player);
    }

    private void PrintToMenu(CCSPlayerController player)
    {
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}--- Menu ---");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}1 {ChatColors.Grey}- Create zone (press for corner 1, move, press again for corner 2)");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}2 {ChatColors.Grey}- Set spawn target at your position");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}3 {ChatColors.Grey}- Delete zone and spawn target");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}4 {ChatColors.Grey}- Save zone to savemap");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}5 {ChatColors.Grey}- Exit menu");
    }

    [ConsoleCommand("css_1", "Create zone corner")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnZoneCorner(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        if (!data.AddingZone)
        {
            var pos = player.Pawn.Value?.CBodyComponent?.SceneNode?.AbsOrigin;
            if (pos == null) return;
            data.Corner1 = $"{pos.X} {pos.Y} {pos.Z}";
            data.Corner2 = null;
            data.AddingZone = true;
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}Corner 1 set. Move to opposite corner and type {ChatColors.White}!1 {ChatColors.Default}again.");
        }
        else
        {
            var pos = player.Pawn.Value?.CBodyComponent?.SceneNode?.AbsOrigin;
            if (pos == null) return;
            data.Corner2 = $"{pos.X} {pos.Y} {pos.Z}";
            data.AddingZone = false;

            var zone = BuildZoneFromPlayerData(data);
            _currentZone = zone;

            SpawnTrigger(zone);
            if (!string.IsNullOrEmpty(data.SpawnTarget))
                SpawnDest(zone);

            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}trigger_teleport created! Set spawn target with !2.");
        }
    }

    [ConsoleCommand("css_2", "Set spawn target")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnSpawnTarget(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        var pos = player.Pawn.Value?.CBodyComponent?.SceneNode?.AbsOrigin;
        var ang = player.PlayerPawn.Value?.EyeAngles;
        if (pos == null || ang == null) return;

        data.SpawnTarget = $"{pos.X} {pos.Y} {pos.Z}";
        data.SpawnAngles = $"{ang.X} {ang.Y} {ang.Z}";

        if (_currentZone != null)
        {
            _currentZone.SpawnTarget = data.SpawnTarget;
            _currentZone.SpawnAngles = data.SpawnAngles;
        }

        if (_currentTrigger != null && _currentTrigger.IsValid)
        {
            SpawnDest(_currentZone ?? BuildZoneFromPlayerData(data));
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}info_teleport_destination set.");
            return;
        }

        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}Spawn target saved. Use !1 to create zone first, or !4 to save all.");
    }

    [ConsoleCommand("css_3", "Delete zone and target")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnDelete(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        try
        {
            data.Corner1 = null;
            data.Corner2 = null;
            data.SpawnTarget = null;
            data.SpawnAngles = null;
            data.AddingZone = false;
            data.LoadedZone = null;
            RemoveBeams(player.Slot);
            RemoveCurrentEntities();
            _currentZone = null;
            _db.DeleteZone(Server.MapName);

            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}Zone deleted.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] OnDelete error: {ex.Message}");
        }
    }

    [ConsoleCommand("css_4", "Save zone to savemap")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnSave(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        if (string.IsNullOrEmpty(data.Corner1) || string.IsNullOrEmpty(data.Corner2))
        {
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Red}You must create a zone first with !1.");
            return;
        }
        if (string.IsNullOrEmpty(data.SpawnTarget))
        {
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Red}You must set a spawn target first with !2.");
            return;
        }

        try
        {
            var zone = new ZoneData
            {
                MapName = Server.MapName,
                Corner1 = data.Corner1,
                Corner2 = data.Corner2,
                SpawnTarget = data.SpawnTarget,
                SpawnAngles = data.SpawnAngles ?? "0 0 0"
            };

            _currentZone = zone;
            data.LoadedZone = zone;
            _db.SaveZone(zone);

            data.InMenu = false;
            data.AddingZone = false;
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}Zone saved to savemap!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] OnSave error: {ex.Message}");
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Red}Error saving zone: {ex.Message}");
        }
    }

    [ConsoleCommand("css_5", "Exit menu")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnExit(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        data.InMenu = false;
        data.AddingZone = false;
        RemoveBeams(player.Slot);
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}Menu closed.");
    }

    private void OnTick()
    {
        if (_currentZone != null && !string.IsNullOrEmpty(_currentZone.Corner1) && !string.IsNullOrEmpty(_currentZone.Corner2))
        {
            var c1 = ParseVector(_currentZone.Corner1);
            var c2 = ParseVector(_currentZone.Corner2);

            var minX = Math.Min(c1.X, c2.X);
            var maxX = Math.Max(c1.X, c2.X);
            var minY = Math.Min(c1.Y, c2.Y);
            var maxY = Math.Max(c1.Y, c2.Y);
            var minZ = Math.Min(c1.Z, c2.Z);
            var maxZ = Math.Max(c1.Z, c2.Z);

            DrawWireframeGlobal(c1, c2);

            if (!string.IsNullOrEmpty(_currentZone.SpawnTarget))
            {
                var destPos = ParseVector(_currentZone.SpawnTarget);
                var destAng = ParseVector(_currentZone.SpawnAngles);
                var qAngle = new QAngle(destAng.X, destAng.Y, destAng.Z);
                var zeroVec = new Vector(0, 0, 0);

                foreach (var player in Utilities.GetPlayers())
                {
                    if (player == null || !player.IsValid || player.IsBot || player.PlayerPawn?.Value == null)
                        continue;

                    var pos = player.PlayerPawn.Value.CBodyComponent?.SceneNode?.AbsOrigin;
                    if (pos == null) continue;

                    if (pos.X >= minX && pos.X <= maxX &&
                        pos.Y >= minY && pos.Y <= maxY &&
                        pos.Z >= minZ && pos.Z <= maxZ)
                    {
                        if (_lastTeleportTime.TryGetValue(player.Slot, out var last))
                        {
                            if (Server.CurrentTime - last < 1.0f) continue;
                        }
                        _lastTeleportTime[player.Slot] = Server.CurrentTime;
                        player.PlayerPawn.Value.Teleport(destPos, qAngle, zeroVec);
                    }
                }
            }
        }

        foreach (var kvp in _players)
        {
            var player = Utilities.GetPlayerFromSlot(kvp.Key);
            if (player == null || !player.IsValid || player.Pawn.Value?.CBodyComponent?.SceneNode?.AbsOrigin == null)
                continue;

            var data = kvp.Value;
            if (!data.InMenu || !data.AddingZone || string.IsNullOrEmpty(data.Corner1))
                continue;

            Vector pos1 = ParseVector(data.Corner1);
            Vector pos2 = player.Pawn.Value.CBodyComponent.SceneNode.AbsOrigin;

            DrawWireframe(pos1, pos2, player);
        }
    }

    private void DrawWireframe(Vector corner1, Vector corner2, CCSPlayerController player)
    {
        var minX = Math.Min(corner1.X, corner2.X);
        var maxX = Math.Max(corner1.X, corner2.X);
        var minY = Math.Min(corner1.Y, corner2.Y);
        var maxY = Math.Max(corner1.Y, corner2.Y);
        var minZ = Math.Min(corner1.Z, corner2.Z);
        var maxZ = Math.Max(corner1.Z, corner2.Z);

        var c1 = new Vector(minX, minY, minZ);
        var c2 = new Vector(maxX, minY, minZ);
        var c3 = new Vector(maxX, maxY, minZ);
        var c4 = new Vector(minX, maxY, minZ);
        var c5 = new Vector(maxX, minY, maxZ);
        var c6 = new Vector(minX, minY, maxZ);
        var c7 = new Vector(minX, maxY, maxZ);
        var c8 = new Vector(maxX, maxY, maxZ);

        var slot = player.Slot;
        DrawBeam(slot, 0, c1, c2);
        DrawBeam(slot, 1, c2, c3);
        DrawBeam(slot, 2, c3, c4);
        DrawBeam(slot, 3, c4, c1);
        DrawBeam(slot, 4, c5, c6);
        DrawBeam(slot, 5, c6, c7);
        DrawBeam(slot, 6, c7, c8);
        DrawBeam(slot, 7, c8, c5);
        DrawBeam(slot, 8, c1, c6);
        DrawBeam(slot, 9, c2, c5);
        DrawBeam(slot, 10, c3, c8);
        DrawBeam(slot, 11, c4, c7);
    }

    private void DrawBeam(int slot, int index, Vector start, Vector end)
    {
        var data = _players.GetValueOrDefault(slot);
        if (data == null) return;

        if (data.Beams.TryGetValue(index, out var existing))
        {
            existing.Remove();
            data.Beams.Remove(index);
        }

        var beam = Utilities.CreateEntityByName<CBeam>("beam");
        if (beam == null) return;

        beam.Render = Color.Blue;
        beam.Width = 2.0f;
        beam.Teleport(start, new QAngle(0, 0, 0), new Vector(0, 0, 0));
        beam.EndPos.X = end.X;
        beam.EndPos.Y = end.Y;
        beam.EndPos.Z = end.Z;
        beam.FadeMinDist = 9999;
        beam.DispatchSpawn();

        data.Beams[index] = beam;
    }

    private void RemoveGlobalBeams()
    {
        foreach (var beam in _globalBeams.Values)
        {
            if (beam.IsValid)
                beam.Remove();
        }
        _globalBeams.Clear();
    }

    private void DrawWireframeGlobal(Vector corner1, Vector corner2)
    {
        RemoveGlobalBeams();

        var minX = Math.Min(corner1.X, corner2.X);
        var maxX = Math.Max(corner1.X, corner2.X);
        var minY = Math.Min(corner1.Y, corner2.Y);
        var maxY = Math.Max(corner1.Y, corner2.Y);
        var minZ = Math.Min(corner1.Z, corner2.Z);
        var maxZ = Math.Max(corner1.Z, corner2.Z);

        var c1 = new Vector(minX, minY, minZ);
        var c2 = new Vector(maxX, minY, minZ);
        var c3 = new Vector(maxX, maxY, minZ);
        var c4 = new Vector(minX, maxY, minZ);
        var c5 = new Vector(maxX, minY, maxZ);
        var c6 = new Vector(minX, minY, maxZ);
        var c7 = new Vector(minX, maxY, maxZ);
        var c8 = new Vector(maxX, maxY, maxZ);

        DrawGlobalBeam(0, c1, c2);
        DrawGlobalBeam(1, c2, c3);
        DrawGlobalBeam(2, c3, c4);
        DrawGlobalBeam(3, c4, c1);
        DrawGlobalBeam(4, c5, c6);
        DrawGlobalBeam(5, c6, c7);
        DrawGlobalBeam(6, c7, c8);
        DrawGlobalBeam(7, c8, c5);
        DrawGlobalBeam(8, c1, c6);
        DrawGlobalBeam(9, c2, c5);
        DrawGlobalBeam(10, c3, c8);
        DrawGlobalBeam(11, c4, c7);
    }

    private void DrawGlobalBeam(int index, Vector start, Vector end)
    {
        if (_globalBeams.TryGetValue(index, out var existing))
        {
            existing.Remove();
            _globalBeams.Remove(index);
        }

        var beam = Utilities.CreateEntityByName<CBeam>("beam");
        if (beam == null) return;

        beam.Render = Color.Blue;
        beam.Width = 2.0f;
        beam.Teleport(start, new QAngle(0, 0, 0), new Vector(0, 0, 0));
        beam.EndPos.X = end.X;
        beam.EndPos.Y = end.Y;
        beam.EndPos.Z = end.Z;
        beam.FadeMinDist = 9999;
        beam.DispatchSpawn();

        _globalBeams[index] = beam;
    }

    private void RemoveBeams(int slot)
    {
        var data = _players.GetValueOrDefault(slot);
        if (data == null) return;

        foreach (var beam in data.Beams.Values)
        {
            if (beam.IsValid)
                beam.Remove();
        }
        data.Beams.Clear();
    }

    private void CleanupPlayer(int slot)
    {
        RemoveBeams(slot);
        _players.Remove(slot);
    }

    private PlayerZoneData GetOrCreatePlayerData(int slot)
    {
        if (!_players.TryGetValue(slot, out var data))
        {
            data = new PlayerZoneData();
            _players[slot] = data;
        }
        return data;
    }

    private static Vector ParseVector(string str)
    {
        var parts = str.Split(' ');
        if (parts.Length >= 3 &&
            float.TryParse(parts[0], out var x) &&
            float.TryParse(parts[1], out var y) &&
            float.TryParse(parts[2], out var z))
            return new Vector(x, y, z);
        return new Vector(0, 0, 0);
    }
}
