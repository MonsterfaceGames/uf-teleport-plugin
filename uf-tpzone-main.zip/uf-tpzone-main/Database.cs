using System.Text.Json;
using MySqlConnector;

namespace uf_tpzone;

public class DbConfig
{
    public string Host { get; set; } = "127.0.0.1";
    public int Port { get; set; } = 3306;
    public string Username { get; set; } = "root";
    public string Password { get; set; } = "";
    public string Database { get; set; } = "tpzone";
}

public class Database
{
    private readonly string _connectionString;

    public Database(string configDir)
    {
        var configPath = Path.Join(configDir, "tpzone-db.json");
        DbConfig config;

        if (!File.Exists(configPath))
        {
            config = new DbConfig();
            var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(configPath, json);
        }
        else
        {
            var json = File.ReadAllText(configPath);
            config = JsonSerializer.Deserialize<DbConfig>(json) ?? new DbConfig();
        }

        var builder = new MySqlConnectionStringBuilder
        {
            Server = string.IsNullOrEmpty(config.Host) ? "127.0.0.1" : config.Host,
            Port = (uint)config.Port,
            UserID = config.Username,
            Password = config.Password,
            Database = string.IsNullOrEmpty(config.Database) ? "tpzone" : config.Database
        };
        _connectionString = builder.ConnectionString;

        InitializeDatabase();
    }

    private void InitializeDatabase()
    {
        using var conn = new MySqlConnection(_connectionString);
        conn.Open();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = @"
            CREATE TABLE IF NOT EXISTS zones (
                Id INT AUTO_INCREMENT PRIMARY KEY,
                MapName VARCHAR(255) NOT NULL UNIQUE,
                Corner1 TEXT NOT NULL,
                Corner2 TEXT NOT NULL,
                SpawnTarget TEXT NOT NULL DEFAULT '',
                SpawnAngles TEXT NOT NULL DEFAULT '0 0 0'
            )
        ";
        cmd.ExecuteNonQuery();

        Console.WriteLine("[TPZone] Database initialized successfully.");
    }

    private MySqlCommand CreateCommand(string query)
    {
        var conn = new MySqlConnection(_connectionString);
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = query;
        return cmd;
    }

    public ZoneData? LoadZone(string mapName)
    {
        using var cmd = CreateCommand("SELECT MapName, Corner1, Corner2, SpawnTarget, SpawnAngles FROM zones WHERE MapName = @map");
        cmd.Parameters.AddWithValue("@map", mapName);
        using var reader = cmd.ExecuteReader();
        if (reader.Read())
            return new ZoneData
            {
                MapName = reader.GetString(0),
                Corner1 = reader.GetString(1),
                Corner2 = reader.GetString(2),
                SpawnTarget = reader.GetString(3),
                SpawnAngles = reader.GetString(4)
            };
        return null;
    }

    public void SaveZone(ZoneData zone)
    {
        using var cmd = CreateCommand(@"
            INSERT INTO zones (MapName, Corner1, Corner2, SpawnTarget, SpawnAngles)
            VALUES (@map, @c1, @c2, @spawn, @ang)
            ON DUPLICATE KEY UPDATE
                Corner1 = @c1, Corner2 = @c2, SpawnTarget = @spawn, SpawnAngles = @ang
        ");
        cmd.Parameters.AddWithValue("@map", zone.MapName);
        cmd.Parameters.AddWithValue("@c1", zone.Corner1);
        cmd.Parameters.AddWithValue("@c2", zone.Corner2);
        cmd.Parameters.AddWithValue("@spawn", zone.SpawnTarget);
        cmd.Parameters.AddWithValue("@ang", zone.SpawnAngles);
        cmd.ExecuteNonQuery();
    }

    public void DeleteZone(string mapName)
    {
        using var cmd = CreateCommand("DELETE FROM zones WHERE MapName = @map");
        cmd.Parameters.AddWithValue("@map", mapName);
        cmd.ExecuteNonQuery();
    }
}
