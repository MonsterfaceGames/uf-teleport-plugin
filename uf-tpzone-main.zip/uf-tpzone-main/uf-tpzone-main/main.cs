using System.Drawing;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Core.Attributes;
using CounterStrikeSharp.API.Core.Attributes.Registration;
using CounterStrikeSharp.API.Modules.Admin;
using CounterStrikeSharp.API.Modules.Commands;
using CounterStrikeSharp.API.Modules.Utils;
using CounterStrikeSharp.API.Modules.Memory;

namespace uf_tpzone;

[MinimumApiVersion(281)]
public class TpZonePlugin : BasePlugin
{
    public override string ModuleName => "UF-TPZone";
    public override string ModuleVersion => "3.0V";
    public override string ModuleAuthor => "monsterfacegames";
    public override string ModuleDescription => "Teleport zone plugin (unlimited zones)";

    private readonly Dictionary<int, PlayerZoneData> _players = new();
    private readonly List<ZoneData> _zones = new();
    private readonly List<CBeam> _globalBeams = new();
    private readonly Dictionary<int, float> _lastTeleportTime = new();
    private int _spawnGen;
    private int _nextTempZoneId = -1;

    private const string TriggerName = "tpzone_trigger";
    private string _configDir = "";
    private Database _db = null!;

    public override void Load(bool hotReload)
    {
        var gameDir = Server.GameDirectory;
        _configDir = Path.Join(gameDir, "csgo", "addons", "counterstrikesharp", "configs", "plugins", "uf-tpzone");

        if (!Directory.Exists(_configDir))
            Directory.CreateDirectory(_configDir);

        _db = new Database(_configDir);

        RegisterListener<Listeners.OnTick>(OnTick);
        RegisterListener<Listeners.OnMapStart>(OnMapStart);

        RegisterEventHandler<EventPlayerDisconnect>((@event, info) =>
        {
            if (@event.Userid is { IsValid: true })
                CleanupPlayer(@event.Userid.Slot);
            return HookResult.Continue;
        });

        RegisterEventHandler<EventRoundStart>((@event, info) =>
        {
            if (_zones.Count > 0)
            {
                Server.NextFrame(() =>
                {
                    foreach (var zone in _zones)
                    {
                        var needsRespawn = zone.Trigger == null || !zone.Trigger.IsValid || zone.Destination == null || !zone.Destination.IsValid;
                        if (needsRespawn)
                        {
                            SpawnTrigger(zone);
                            SpawnDest(zone);
                        }
                    }
                });
            }
            return HookResult.Continue;
        });
    }

    private List<ZoneData> LoadZonesFromDb(string mapName)
    {
        try
        {
            return _db.LoadZones(mapName);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] LoadZonesFromDb error: {ex.Message}");
            return new List<ZoneData>();
        }
    }

    private void OnMapStart(string mapName)
    {
        RemoveAllEntities();
        foreach (var kvp in _players)
            CleanupPlayer(kvp.Key);
        _players.Clear();
        _lastTeleportTime.Clear();
        _zones.Clear();
        _nextTempZoneId = -1;

        try
        {
            var zones = LoadZonesFromDb(mapName);
            if (zones.Count > 0)
            {
                _zones.AddRange(zones);
                Server.NextFrame(() =>
                {
                    try
                    {
                        foreach (var zone in _zones)
                        {
                            SpawnTrigger(zone);
                            SpawnDest(zone);
                        }
                        Console.WriteLine($"[TPZone] Loaded {zones.Count} zones for {mapName} from database.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[TPZone] Auto-spawn error: {ex.Message}");
                    }
                });
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] OnMapStart error: {ex.Message}");
        }
    }

    private ZoneData BuildZoneFromPlayerData(PlayerZoneData data)
    {
        return new ZoneData
        {
            MapName = Server.MapName,
            Corner1 = data.Corner1 ?? "",
            Corner2 = data.Corner2 ?? "",
            SpawnTarget = data.SpawnTarget ?? "",
            SpawnAngles = data.SpawnAngles ?? "0 0 0"
        };
    }

    private string GetDestName(int zoneId)
    {
        return $"uf-tpzone-{zoneId}";
    }

    private void SpawnTrigger(ZoneData zone)
    {
        try
        {
            if (zone.Trigger != null && zone.Trigger.IsValid)
                zone.Trigger.Remove();

            var c1 = ParseVector(zone.Corner1);
            var c2 = ParseVector(zone.Corner2);

            var minX = Math.Min(c1.X, c2.X);
            var maxX = Math.Max(c1.X, c2.X);
            var minY = Math.Min(c1.Y, c2.Y);
            var maxY = Math.Max(c1.Y, c2.Y);
            var minZ = Math.Min(c1.Z, c2.Z);
            var maxZ = Math.Max(c1.Z, c2.Z);

            var center = new Vector((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2);

            var trigger = Utilities.CreateEntityByName<CBaseTrigger>("trigger_teleport");
            if (trigger == null || !trigger.IsValid || trigger.Entity == null) return;
            trigger.Entity.Name = TriggerName;
            trigger.Target = GetDestName(zone.Id);
            trigger.Teleport(center, new QAngle(0, 0, 0), new Vector(0, 0, 0));
            if (trigger.Collision == null) return;
            trigger.Collision.Mins.X = minX - center.X;
            trigger.Collision.Mins.Y = minY - center.Y;
            trigger.Collision.Mins.Z = minZ - center.Z;
            trigger.Collision.Maxs.X = maxX - center.X;
            trigger.Collision.Maxs.Y = maxY - center.Y;
            trigger.Collision.Maxs.Z = maxZ - center.Z;
            trigger.DispatchSpawn();

            var capturedGen = ++_spawnGen;
            var capturedTrigger = trigger;
            Server.NextFrame(() =>
            {
                if (_spawnGen != capturedGen) return;
                try
                {
                    if (capturedTrigger.IsValid && capturedTrigger.Collision != null)
                        capturedTrigger.Collision.SolidType = (SolidType_t)2;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[TPZone] Solid type error: {ex.Message}");
                }
            });

            zone.Trigger = trigger;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] SpawnTrigger error: {ex.Message}");
        }
    }

    private void SpawnDest(ZoneData zone)
    {
        if (zone.Destination != null && zone.Destination.IsValid)
            zone.Destination.Remove();

        try
        {
            var spawnPos = ParseVector(zone.SpawnTarget);
            var spawnAng = ParseVector(zone.SpawnAngles);

            var dest = Utilities.CreateEntityByName<CInfoTeleportDestination>("info_teleport_destination");
            if (dest == null || dest.Entity == null) return;
            dest.Entity.Name = GetDestName(zone.Id);
            dest.Teleport(spawnPos, new QAngle(spawnAng.X, spawnAng.Y, spawnAng.Z), new Vector(0, 0, 0));
            dest.DispatchSpawn();
            zone.Destination = dest;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] Failed to spawn destination: {ex.Message}");
        }
    }

    private void RemoveAllEntities()
    {
        foreach (var zone in _zones)
        {
            if (zone.Trigger != null && zone.Trigger.IsValid)
                zone.Trigger.Remove();
            if (zone.Destination != null && zone.Destination.IsValid)
                zone.Destination.Remove();
            zone.Trigger = null;
            zone.Destination = null;
        }
        RemoveGlobalBeams();
        _spawnGen++;
    }

    [ConsoleCommand("css_tpzone", "Open TPZone menu")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnTpZoneMenu(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;

        var data = GetOrCreatePlayerData(player.Slot);
        data.InMenu = true;
        PrintToMenu(player);
    }

    private void PrintToMenu(CCSPlayerController player)
    {
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}--- Menu ---");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}1 {ChatColors.Grey}- Create zone (press for corner 1, move, press again for corner 2)");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}2 {ChatColors.Grey}- Set spawn target at your position");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}3 {ChatColors.Grey}- List all zones");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}4 {ChatColors.Grey}- Save zone to database");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}5 <id> {ChatColors.Grey}- Delete zone by ID");
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}!{ChatColors.White}6 {ChatColors.Grey}- Exit menu");
    }

    [ConsoleCommand("css_1", "Create zone corner")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnZoneCorner(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        if (!data.AddingZone)
        {
            var pos = player.Pawn.Value?.CBodyComponent?.SceneNode?.AbsOrigin;
            if (pos == null) return;
            data.Corner1 = $"{pos.X} {pos.Y} {pos.Z}";
            data.Corner2 = null;
            data.AddingZone = true;
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}Corner 1 set. Move to opposite corner and type {ChatColors.White}!1 {ChatColors.Default}again.");
        }
        else
        {
            var pos = player.Pawn.Value?.CBodyComponent?.SceneNode?.AbsOrigin;
            if (pos == null) return;
            data.Corner2 = $"{pos.X} {pos.Y} {pos.Z}";
            data.AddingZone = false;

            var zone = BuildZoneFromPlayerData(data);
            zone.Id = _nextTempZoneId--;
            _zones.Add(zone);
            data.LoadedZone = zone;

            SpawnTrigger(zone);
            if (!string.IsNullOrEmpty(data.SpawnTarget))
                SpawnDest(zone);

            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}trigger_teleport created! Set spawn target with !2 and save with !4.");
        }
    }

    [ConsoleCommand("css_2", "Set spawn target")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnSpawnTarget(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        var pos = player.Pawn.Value?.CBodyComponent?.SceneNode?.AbsOrigin;
        var ang = player.PlayerPawn.Value?.EyeAngles;
        if (pos == null || ang == null) return;

        data.SpawnTarget = $"{pos.X} {pos.Y} {pos.Z}";
        data.SpawnAngles = $"{ang.X} {ang.Y} {ang.Z}";

        if (data.LoadedZone != null)
        {
            data.LoadedZone.SpawnTarget = data.SpawnTarget;
            data.LoadedZone.SpawnAngles = data.SpawnAngles;
        }

        if (data.LoadedZone != null)
        {
            SpawnDest(data.LoadedZone);
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}info_teleport_destination set for zone.");
            return;
        }

        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}Spawn target saved. Use !1 to create a zone first, then !2 to set the destination.");
    }

    [ConsoleCommand("css_3", "List all zones")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnListZones(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        if (_zones.Count == 0)
        {
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}No zones on this map.");
            return;
        }

        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}Zones on this map ({_zones.Count}):");
        for (int i = 0; i < _zones.Count; i++)
        {
            var zone = _zones[i];
            var status = zone.Id > 0 ? "saved" : "unsaved";
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.White}{i + 1}. {ChatColors.Default}ID: {zone.Id} ({status})");
        }
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}Use !5 <id> to delete a zone.");
    }

    [ConsoleCommand("css_4", "Save zone to database")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnSave(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        if (string.IsNullOrEmpty(data.Corner1) || string.IsNullOrEmpty(data.Corner2))
        {
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Red}You must create a zone first with !1.");
            return;
        }
        if (string.IsNullOrEmpty(data.SpawnTarget))
        {
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Red}You must set a spawn target first with !2.");
            return;
        }

        try
        {
            ZoneData zone;
            if (data.LoadedZone != null && _zones.Contains(data.LoadedZone))
            {
                zone = data.LoadedZone;
                zone.Corner1 = data.Corner1;
                zone.Corner2 = data.Corner2;
                zone.SpawnTarget = data.SpawnTarget;
                zone.SpawnAngles = data.SpawnAngles ?? "0 0 0";
            }
            else
            {
                zone = BuildZoneFromPlayerData(data);
                _zones.Add(zone);
                data.LoadedZone = zone;
            }

            zone.MapName = Server.MapName;
            var newId = _db.SaveZone(zone);
            zone.Id = newId;

            SpawnTrigger(zone);
            SpawnDest(zone);

            data.InMenu = false;
            data.AddingZone = false;
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}Zone #{zone.Id} saved to database!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TPZone] OnSave error: {ex.Message}");
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Red}Error saving zone: {ex.Message}");
        }
    }

    [ConsoleCommand("css_5", "Delete zone by ID")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnDelete(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        if (!data.InMenu) return;

        if (command.ArgCount < 2 || !int.TryParse(command.ArgByIndex(1), out var zoneId))
        {
            data.Corner1 = null;
            data.Corner2 = null;
            data.SpawnTarget = null;
            data.SpawnAngles = null;
            data.AddingZone = false;
            if (data.LoadedZone != null)
            {
                if (data.LoadedZone.Id < 0 && _zones.Contains(data.LoadedZone))
                {
                    if (data.LoadedZone.Trigger != null && data.LoadedZone.Trigger.IsValid)
                        data.LoadedZone.Trigger.Remove();
                    if (data.LoadedZone.Destination != null && data.LoadedZone.Destination.IsValid)
                        data.LoadedZone.Destination.Remove();
                    _zones.Remove(data.LoadedZone);
                }
                data.LoadedZone = null;
            }
            RemoveBeams(player.Slot);
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}Editor state cleared. Use !5 <id> to delete a saved zone.");
            return;
        }

        var zone = _zones.FirstOrDefault(z => z.Id == zoneId);
        if (zone == null)
        {
            player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Red}Zone #{zoneId} not found.");
            return;
        }

        if (zone.Id > 0)
            _db.DeleteZone(zone.Id);

        if (zone.Trigger != null && zone.Trigger.IsValid)
            zone.Trigger.Remove();
        if (zone.Destination != null && zone.Destination.IsValid)
            zone.Destination.Remove();

        _zones.Remove(zone);

        foreach (var kvp in _players)
        {
            if (kvp.Value.LoadedZone == zone)
                kvp.Value.LoadedZone = null;
        }

        data.Corner1 = null;
        data.Corner2 = null;
        data.SpawnTarget = null;
        data.SpawnAngles = null;
        data.AddingZone = false;
        RemoveBeams(player.Slot);

        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Green}Zone #{zoneId} deleted.");
    }

    [ConsoleCommand("css_6", "Exit menu")]
    [RequiresPermissions("@css/root")]
    [CommandHelper(whoCanExecute: CommandUsage.CLIENT_ONLY)]
    public void OnExit(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        var data = GetOrCreatePlayerData(player.Slot);
        data.InMenu = false;
        data.AddingZone = false;
        RemoveBeams(player.Slot);
        player.PrintToChat($" {ChatColors.Blue}[TPZone] {ChatColors.Default}Menu closed.");
    }

    private void OnTick()
    {
        if (_zones.Count > 0)
        {
            RemoveGlobalBeams();

            foreach (var zone in _zones)
            {
                if (string.IsNullOrEmpty(zone.Corner1) || string.IsNullOrEmpty(zone.Corner2))
                    continue;

                var c1 = ParseVector(zone.Corner1);
                var c2 = ParseVector(zone.Corner2);

                var minX = Math.Min(c1.X, c2.X);
                var maxX = Math.Max(c1.X, c2.X);
                var minY = Math.Min(c1.Y, c2.Y);
                var maxY = Math.Max(c1.Y, c2.Y);
                var minZ = Math.Min(c1.Z, c2.Z);
                var maxZ = Math.Max(c1.Z, c2.Z);

                DrawWireframeGlobal(c1, c2);

                if (!string.IsNullOrEmpty(zone.SpawnTarget))
                {
                    var destPos = ParseVector(zone.SpawnTarget);
                    var destAng = ParseVector(zone.SpawnAngles);
                    var qAngle = new QAngle(destAng.X, destAng.Y, destAng.Z);
                    var zeroVec = new Vector(0, 0, 0);

                    foreach (var player in Utilities.GetPlayers())
                    {
                        if (player == null || !player.IsValid || player.IsBot || player.PlayerPawn?.Value == null)
                            continue;

                        var pos = player.PlayerPawn.Value.CBodyComponent?.SceneNode?.AbsOrigin;
                        if (pos == null) continue;

                        if (pos.X >= minX && pos.X <= maxX &&
                            pos.Y >= minY && pos.Y <= maxY &&
                            pos.Z >= minZ && pos.Z <= maxZ)
                        {
                            if (_lastTeleportTime.TryGetValue(player.Slot, out var last))
                            {
                                if (Server.CurrentTime - last < 1.0f) continue;
                            }
                            _lastTeleportTime[player.Slot] = Server.CurrentTime;
                            player.PlayerPawn.Value.Teleport(destPos, qAngle, zeroVec);
                        }
                    }
                }
            }
        }

        foreach (var kvp in _players)
        {
            var player = Utilities.GetPlayerFromSlot(kvp.Key);
            if (player == null || !player.IsValid || player.Pawn.Value?.CBodyComponent?.SceneNode?.AbsOrigin == null)
                continue;

            var data = kvp.Value;
            if (!data.InMenu || !data.AddingZone || string.IsNullOrEmpty(data.Corner1))
                continue;

            Vector pos1 = ParseVector(data.Corner1);
            Vector pos2 = player.Pawn.Value.CBodyComponent.SceneNode.AbsOrigin;

            DrawWireframe(pos1, pos2, player);
        }
    }

    private void DrawWireframe(Vector corner1, Vector corner2, CCSPlayerController player)
    {
        var minX = Math.Min(corner1.X, corner2.X);
        var maxX = Math.Max(corner1.X, corner2.X);
        var minY = Math.Min(corner1.Y, corner2.Y);
        var maxY = Math.Max(corner1.Y, corner2.Y);
        var minZ = Math.Min(corner1.Z, corner2.Z);
        var maxZ = Math.Max(corner1.Z, corner2.Z);

        var c1 = new Vector(minX, minY, minZ);
        var c2 = new Vector(maxX, minY, minZ);
        var c3 = new Vector(maxX, maxY, minZ);
        var c4 = new Vector(minX, maxY, minZ);
        var c5 = new Vector(maxX, minY, maxZ);
        var c6 = new Vector(minX, minY, maxZ);
        var c7 = new Vector(minX, maxY, maxZ);
        var c8 = new Vector(maxX, maxY, maxZ);

        var slot = player.Slot;
        DrawBeam(slot, 0, c1, c2);
        DrawBeam(slot, 1, c2, c3);
        DrawBeam(slot, 2, c3, c4);
        DrawBeam(slot, 3, c4, c1);
        DrawBeam(slot, 4, c5, c6);
        DrawBeam(slot, 5, c6, c7);
        DrawBeam(slot, 6, c7, c8);
        DrawBeam(slot, 7, c8, c5);
        DrawBeam(slot, 8, c1, c6);
        DrawBeam(slot, 9, c2, c5);
        DrawBeam(slot, 10, c3, c8);
        DrawBeam(slot, 11, c4, c7);
    }

    private void DrawBeam(int slot, int index, Vector start, Vector end)
    {
        var data = _players.GetValueOrDefault(slot);
        if (data == null) return;

        if (data.Beams.TryGetValue(index, out var existing))
        {
            existing.Remove();
            data.Beams.Remove(index);
        }

        var beam = Utilities.CreateEntityByName<CBeam>("beam");
        if (beam == null) return;

        beam.Render = Color.Blue;
        beam.Width = 2.0f;
        beam.Teleport(start, new QAngle(0, 0, 0), new Vector(0, 0, 0));
        beam.EndPos.X = end.X;
        beam.EndPos.Y = end.Y;
        beam.EndPos.Z = end.Z;
        beam.FadeMinDist = 9999;
        beam.DispatchSpawn();

        data.Beams[index] = beam;
    }

    private void RemoveGlobalBeams()
    {
        foreach (var beam in _globalBeams)
        {
            if (beam.IsValid)
                beam.Remove();
        }
        _globalBeams.Clear();
    }

    private void DrawWireframeGlobal(Vector corner1, Vector corner2)
    {
        var minX = Math.Min(corner1.X, corner2.X);
        var maxX = Math.Max(corner1.X, corner2.X);
        var minY = Math.Min(corner1.Y, corner2.Y);
        var maxY = Math.Max(corner1.Y, corner2.Y);
        var minZ = Math.Min(corner1.Z, corner2.Z);
        var maxZ = Math.Max(corner1.Z, corner2.Z);

        var c1 = new Vector(minX, minY, minZ);
        var c2 = new Vector(maxX, minY, minZ);
        var c3 = new Vector(maxX, maxY, minZ);
        var c4 = new Vector(minX, maxY, minZ);
        var c5 = new Vector(maxX, minY, maxZ);
        var c6 = new Vector(minX, minY, maxZ);
        var c7 = new Vector(minX, maxY, maxZ);
        var c8 = new Vector(maxX, maxY, maxZ);

        DrawGlobalBeam(c1, c2);
        DrawGlobalBeam(c2, c3);
        DrawGlobalBeam(c3, c4);
        DrawGlobalBeam(c4, c1);
        DrawGlobalBeam(c5, c6);
        DrawGlobalBeam(c6, c7);
        DrawGlobalBeam(c7, c8);
        DrawGlobalBeam(c8, c5);
        DrawGlobalBeam(c1, c6);
        DrawGlobalBeam(c2, c5);
        DrawGlobalBeam(c3, c8);
        DrawGlobalBeam(c4, c7);
    }

    private void DrawGlobalBeam(Vector start, Vector end)
    {
        var beam = Utilities.CreateEntityByName<CBeam>("beam");
        if (beam == null) return;

        beam.Render = Color.Blue;
        beam.Width = 2.0f;
        beam.Teleport(start, new QAngle(0, 0, 0), new Vector(0, 0, 0));
        beam.EndPos.X = end.X;
        beam.EndPos.Y = end.Y;
        beam.EndPos.Z = end.Z;
        beam.FadeMinDist = 9999;
        beam.DispatchSpawn();

        _globalBeams.Add(beam);
    }

    private void RemoveBeams(int slot)
    {
        var data = _players.GetValueOrDefault(slot);
        if (data == null) return;

        foreach (var beam in data.Beams.Values)
        {
            if (beam.IsValid)
                beam.Remove();
        }
        data.Beams.Clear();
    }

    private void CleanupPlayer(int slot)
    {
        RemoveBeams(slot);
        _players.Remove(slot);
    }

    private PlayerZoneData GetOrCreatePlayerData(int slot)
    {
        if (!_players.TryGetValue(slot, out var data))
        {
            data = new PlayerZoneData();
            _players[slot] = data;
        }
        return data;
    }

    private static Vector ParseVector(string str)
    {
        var parts = str.Split(' ');
        if (parts.Length >= 3 &&
            float.TryParse(parts[0], out var x) &&
            float.TryParse(parts[1], out var y) &&
            float.TryParse(parts[2], out var z))
            return new Vector(x, y, z);
        return new Vector(0, 0, 0);
    }
}
