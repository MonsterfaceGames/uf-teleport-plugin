using CounterStrikeSharp.API.Core;

namespace uf_tpzone;

public class ZoneData
{
    public string MapName { get; set; } = "";
    public string Corner1 { get; set; } = "";
    public string Corner2 { get; set; } = "";
    public string SpawnTarget { get; set; } = "";
    public string SpawnAngles { get; set; } = "";
}

public class PlayerZoneData
{
    public bool InMenu { get; set; }
    public bool AddingZone { get; set; }
    public string? Corner1 { get; set; }
    public string? Corner2 { get; set; }
    public string? SpawnTarget { get; set; }
    public string? SpawnAngles { get; set; }
    public Dictionary<int, CBeam> Beams { get; set; } = new();
    public ZoneData? LoadedZone { get; set; }
}
